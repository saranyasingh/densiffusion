# Larger waveform imputation gate

This follow-up first tests whether the successful larger GP configuration learns
useful waveform interpolation. Forecasting is conditional on both validation
imputation and a separate frozen-model resolution-transfer diagnostic passing.
The earlier [waveform experiment](waveform_forecasting.md) and its results remain
unchanged. No GP weights are reused.

## Recovered recipe

`outputs/csdi-gp-better/plan.json` and `selection.json` identify the selected
`reference_size` configuration. The network has 413,521 parameters: four residual
blocks, 64 hidden channels, eight attention heads, 128-dimensional time and
diffusion embeddings, a 16-dimensional feature embedding, feedforward dimension
64, and dropout 0.1. Univariate feature attention is bypassed as in the existing
implementation.

The first attempt reproduces the saved 200-epoch training recipe: Adam with
learning rate 0.001, batch size 64, weight decay `1e-6`, gradient clipping at 1,
and 50 quadratic diffusion steps with betas from `1e-4` to `0.5`. Learning rate
drops by a factor of ten after epochs 150 and 180. All-step denoising validation
evaluates every diffusion step every ten epochs. The waveform task retains
1,024 training and 256 validation trajectories, each with 33 original-grid points,
for each seed 27101, 27102, and 27103. Original `train_validation.npz` files are
copied byte-for-byte. There is no normalization, latent input, or fine-grid truth
in training or validation selection.

The GP run selected checkpoints by denoising loss. This follow-up instead selects
by hidden-point empirical interpolation CRPS, evaluated on all 256 validation
trajectories with 64 samples every 50 epochs and at the final epoch in the initial
200-epoch attempt. Intermediate
all-step denoising losses cannot replace a CRPS-selected checkpoint. The trainer's
optional `validation_score_interval` separates those two validation schedules
while preserving RNG and model modes around custom callbacks.

## Gates and bounded adjustment

The exact training geometry observes the 17 even points at spacing 0.2 and
imputes the 16 odd points at spacing 0.1. All metrics score hidden points only;
observations must be preserved exactly. The linear baseline averages neighboring
observations and repeats that deterministic estimate, so its interval width and
continuous-target coverage are zero.

The validation gate was recorded before any new candidate scores were inspected:

- Learned CRPS must be lower than linear CRPS in each of the three seeds.
- The reduction in mean CRPS across seeds must be at least 5%.
- Each seed's paired trajectory-bootstrap 95% interval for learned minus linear
  CRPS must have a negative upper endpoint.

These are development criteria on reused validation data, conditional on fitted
models and sampled ensembles. They are not confirmatory test confidence claims.
The bootstrap retains all hidden times of each independent trajectory together.
Seed variation is reported separately. Checkpoint and attempt selection reuse
validation data, and the intervals are not adjusted for those decisions.

At most two training attempts are permitted: the exact 200-epoch recipe and,
if its gate fails after validation-only diagnostics, one fresh 600-epoch run with
the same architecture, distribution, splits, optimizer, and diffusion schedule.
The longer run stretches the learning-rate milestones to 450 and 540 and scores
CRPS at epochs 150, 300, 450, and 600. Both attempts therefore have four CRPS
checkpoint opportunities, while all-step denoising validation stays every ten
epochs. This bounds the substantial sampling cost. The longer run does
not resume a decayed optimizer or load GP weights. No transfer truth is generated
while these choices remain open.

After a passing validation gate, all three selected densifiers and their
configuration/analysis hashes are frozen. A separate diagnostic generates 256
fresh trajectories per seed on the fine grid. It evaluates the actual application
geometries: a 49-point history and a 17-point future with its left anchor. Each
task has original spacing 0.1 and output spacing 0.05. Simulator truth is used
only to score these frozen samples. For each seed and task, learned CRPS must
be at most 1.25 times linear CRPS and ensemble-mean MSE at most 1.5 times linear
MSE. This is an adequacy screen, not a requirement to beat linear or proof of
resolution invariance. Failure stops the follow-up; fine truth is never used to
adjust weights, hyperparameters, or checkpoint selection.

Only if both gates pass may forecasting proceed with paired larger forecasters,
the original independent history/future densification construction, and fresh
forecast test trajectories generated after all forecast choices are frozen.

## Reproduce and inspect

From the repository root, use fresh output directories:

```sh
uv run --locked python scripts/train_waveform_imputation.py --smoke --output outputs/waveform-large-smoke
uv run --locked python scripts/train_waveform_imputation.py --config configs/waveform_imputation_large.json --output outputs/waveform-large-imputation
uv run --locked python scripts/analyze_waveform_imputation.py outputs/waveform-large-imputation
```

The analysis module `waveform_imputation_analysis.analyze_imputation_run` reads
the saved validation ensembles, computes metrics and paired intervals, and
writes the validation gate and SVG plots. Then freeze the selected densifiers:

```sh
uv run --locked python scripts/train_waveform_imputation.py --phase freeze --output outputs/waveform-large-imputation
```

If the validation gate passes, the separate transfer phase is available:

```sh
uv run --locked python scripts/train_waveform_imputation.py --phase transfer --output outputs/waveform-large-imputation
uv run --locked python scripts/analyze_waveform_imputation.py --transfer outputs/waveform-large-imputation
```

Artifacts include source/configuration snapshots, original data hashes and copies,
initialization hashes, selected checkpoints, every epoch's logs, exact scored
samples for every CRPS candidate, aggregate and per-hidden-time metrics,
bootstrap intervals, reconstruction plots, and wall timings. Three independent
CPU workers each use one Torch thread; reported worker times are measured under
concurrent execution. Training totals include checkpoint-validation costs, which
are recorded separately. A larger architecture or a completed epoch budget does
not establish convergence.
