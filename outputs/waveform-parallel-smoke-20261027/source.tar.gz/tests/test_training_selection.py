from dataclasses import replace

import numpy as np
import pytest

torch = pytest.importorskip("torch")

from densiffusion.training import (  # noqa: E402
    TrainingConfig,
    train_densifier,
    train_forecaster,
)


class ScalarDenoiser(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.value = torch.nn.Parameter(torch.tensor(1.0))
        self.dropout = torch.nn.Dropout(0.25)

    def forward(self, noisy, steps, **kwargs):
        return torch.ones_like(noisy) * self.value


@pytest.fixture
def config():
    return TrainingConfig(epochs=3, batch_size=2, diffusion_steps=2, learning_rate=0.1)


def squared_prediction(prediction, batch):
    return prediction.square().mean()


def fit(stage, model, config, **kwargs):
    data = np.ones((2, 5, 1))
    if stage == "densifier":
        return train_densifier(model, data, data, config=config, **kwargs)
    pair = data[:, :3], data[:, 3:]
    return train_forecaster(model, None, pair, pair, factor=1, config=config, **kwargs)


@pytest.mark.parametrize("stage", ["densifier", "forecaster"])
def test_custom_score_selects_checkpoint_instead_of_denoising_loss(
    stage, config, tmp_path
):
    model = ScalarDenoiser()
    states = {}
    records = []

    def forecast_crps(current, epoch):
        assert current is model
        assert not torch.is_grad_enabled()
        assert not any(module.training for module in current.modules())
        states[epoch] = current.value.detach().clone()
        return float((epoch - 2) ** 2)

    checkpoint = tmp_path / "selected.pt"
    fit(
        stage,
        model,
        config,
        objective=squared_prediction,
        validation_score=forecast_crps,
        epoch_callback=records.append,
        checkpoint=checkpoint,
    )
    assert records[2]["validation_loss"] < records[1]["validation_loss"]
    torch.testing.assert_close(model.value, states[2], rtol=0, atol=0)
    saved = torch.load(checkpoint, weights_only=True)
    assert saved["epoch"] == 2
    assert saved["selection_score"] == 0
    assert saved["selection_metric"].endswith("forecast_crps")
    assert saved["validation_loss"] == records[1]["validation_loss"]
    assert not model.training


def test_callbacks_include_every_epoch_and_only_validated_metrics(config):
    model = ScalarDenoiser()
    records = []
    scored_epochs = []

    def score(current, epoch):
        scored_epochs.append(epoch)
        return -epoch

    fit(
        "densifier",
        model,
        replace(config, epochs=5, validation_interval=2),
        validation_score=score,
        epoch_callback=records.append,
    )
    assert [row["epoch"] for row in records] == [1, 2, 3, 4, 5]
    assert scored_epochs == [2, 4, 5]
    for row in records:
        assert {"epoch", "train_loss", "learning_rate"} <= row.keys()
        if row["epoch"] in scored_epochs:
            assert row["selection_score"] == -row["epoch"]
            assert {"validation_loss", "selection_metric"} <= row.keys()
        else:
            assert "validation_loss" not in row
            assert "selection_score" not in row


DEVICES = ["cpu"]
if torch.backends.mps.is_available():
    DEVICES.append("mps")
if torch.cuda.is_available():
    DEVICES.append("cuda")


@pytest.mark.parametrize("device", DEVICES)
def test_monitoring_does_not_perturb_training_rng_or_modes(config, device):
    class StochasticDenoiser(ScalarDenoiser):
        def forward(self, noisy, steps, **kwargs):
            assert self.training == torch.is_grad_enabled()
            return self.value * self.dropout(noisy)

    runs = []
    for perturb in (False, True):
        model = StochasticDenoiser()
        records = []

        def score(current, epoch, perturb=perturb):
            assert not current.training and not current.dropout.training
            if perturb:
                torch.manual_seed(999)
                torch.randn(51)
                torch.randn(31, device=device)
                current.train()
                current.dropout.eval()
            return -epoch

        def callback(record, model=model, records=records, perturb=perturb):
            # Validation leaves the model in eval; training-only epochs do not.
            expected_training = record["epoch"] not in (2, 3)
            assert model.training == expected_training
            assert model.dropout.training == expected_training
            records.append(record.copy())
            if perturb:
                torch.manual_seed(47)
                torch.randn(19, device=device)
                model.train(not expected_training)

        fit(
            "densifier",
            model,
            replace(config, validation_interval=2, device=device),
            validation_score=score,
            epoch_callback=callback,
            seed=71,
        )
        runs.append((model.value.detach().cpu(), records, torch.get_rng_state()))
    torch.testing.assert_close(runs[0][0], runs[1][0], rtol=0, atol=0)
    assert runs[0][1] == runs[1][1]
    assert torch.equal(runs[0][2], runs[1][2])


@pytest.mark.parametrize("score", [float("nan"), float("inf"), -float("inf")])
def test_nonfinite_validation_score_is_rejected_without_checkpoint(
    config, tmp_path, score
):
    checkpoint = tmp_path / "invalid.pt"
    with pytest.raises(FloatingPointError, match="Non-finite validation_score"):
        fit(
            "densifier",
            ScalarDenoiser(),
            config,
            validation_score=lambda model, epoch: score,
            checkpoint=checkpoint,
        )
    assert not checkpoint.exists()


def test_score_exception_restores_mode_and_rng(config):
    model = ScalarDenoiser()
    before = {}

    def fail(current, epoch):
        before["rng"] = torch.get_rng_state()
        current.train()
        torch.randn(31)
        raise RuntimeError("scoring failed")

    with pytest.raises(RuntimeError, match="scoring failed"):
        fit("densifier", model, config, validation_score=fail)
    assert not any(module.training for module in model.modules())
    assert torch.equal(torch.get_rng_state(), before["rng"])


def test_default_checkpoint_still_uses_validation_loss(config, tmp_path):
    checkpoint = tmp_path / "default.pt"
    fit(
        "densifier",
        ScalarDenoiser(),
        config,
        objective=squared_prediction,
        checkpoint=checkpoint,
    )
    saved = torch.load(checkpoint, weights_only=True)
    assert saved["epoch"] == config.epochs
    assert saved["selection_score"] == saved["validation_loss"]
    assert saved["selection_metric"] == "validation_loss"
