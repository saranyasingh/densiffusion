"""Independently audit saved polishing forecasts without fitting or diffusion sampling."""

import argparse
import hashlib
import json
import math
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import torch

from densiffusion.architectures.csdi import CSDIDenoiser
from densiffusion.generators.noisy_periodic import generate_noisy_periodic
from densiffusion.history_polishing import BlindSpotMediator, load_mediator
from densiffusion.metrics import evaluate_forecast
from densiffusion.models import ImputationModel

METHODS = ("raw", "learned", "median")
METRICS = ("crps", "mse", "coverage_90", "interval_width_90")
OFFSETS = (-3, -2, -1, 1, 2, 3)


def require(condition, description):
    if not condition:
        raise ValueError(description)


def read(path):
    return json.loads(Path(path).read_text())


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def array_hash(values):
    values = np.ascontiguousarray(values)
    digest = hashlib.sha256()
    digest.update(str(values.shape).encode())
    digest.update(values.dtype.str.encode())
    digest.update(values.tobytes())
    return digest.hexdigest()


def mediator_state_hash(state):
    digest = hashlib.sha256()
    for name, values in sorted(state.items()):
        digest.update(name.encode())
        digest.update(array_hash(values.detach().cpu().numpy()).encode())
    return digest.hexdigest()


def forecaster_state_hash(model):
    digest = hashlib.sha256()
    for name, value in model.state_dict().items():
        digest.update(name.encode())
        digest.update(value.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def equal(actual, expected, description):
    require(np.array_equal(actual, expected), f"{description} differs")


def verify_hashes(root, hashes, description):
    for name, expected in hashes.items():
        require(sha256(root / name) == expected, f"{description} changed: {name}")


def neighbor_features(history):
    """Independent fixed-slot reconstruction; no center or future is available."""
    require(history.ndim == 3 and history.shape[1:] == (32, 1), "History must be 32x1")
    features = np.zeros((len(history), 32, 12), dtype=np.float64)
    for center in range(32):
        for slot, offset in enumerate(OFFSETS):
            neighbor = center + offset
            if 0 <= neighbor < 32:
                features[:, center, slot] = history[:, neighbor, 0]
                features[:, center, slot + 6] = 1.0
    return features


def learned_history(model, history):
    features = neighbor_features(history)
    parameter = next(model.parameters())
    model.eval()
    with torch.inference_mode():
        return (
            model(
                torch.as_tensor(
                    features, dtype=parameter.dtype, device=parameter.device
                )
            )
            .cpu()
            .numpy()
            .astype(np.float64)
        )


def median_history(history):
    result = np.empty_like(history)
    for center in range(32):
        neighbors = np.clip(np.arange(center - 3, center + 4), 0, 31)
        result[:, center] = np.median(history[:, neighbors], axis=1)
    return result


def verify_mediator(directory, train, validation, seed, device, smoke):
    """Recompute candidate/epoch choice from noisy-center predictions only."""
    summary = read(directory / "summary.json")
    require(
        summary["seed"] == seed
        and summary["smoke"] is smoke
        and summary["selection_metric"] == "noisy_center_validation_mse"
        and summary["selection_ties"] == "first_in_epoch_then_candidate_order",
        "Mediator selection protocol differs",
    )
    require(
        summary["train_shape"] == list(train.shape)
        and summary["validation_shape"] == list(validation.shape)
        and summary["train_history_sha256"] == array_hash(train)
        and summary["validation_history_sha256"] == array_hash(validation)
        and summary["validation_centers"] == validation.size
        and summary["center_excluded_from_features"] is True
        and summary["clean_values_or_future_observations_accessed"] is False,
        "Mediator inputs are not the noisy histories alone",
    )
    epochs = 5 if smoke else 200
    score_epochs = sorted({1, 5, *range(10, epochs + 1, 10), epochs})
    candidates = summary["candidates"]
    choices = [(width, loss) for width in (32, 64) for loss in ("mse", "huber")]
    require(len(candidates) == len(choices), "Mediator candidate inventory differs")
    streams = np.random.SeedSequence(seed).spawn(4)
    for index, (candidate, (width, loss)) in enumerate(
        zip(candidates, choices, strict=True)
    ):
        name = f"candidate_{index:02d}_{width}_{loss}"
        require(candidate["name"] == name, "Mediator candidate ordering differs")
        folder = directory / name
        initialization, shuffle = streams[index].spawn(2)
        expected_config = {
            "hidden_channels": width,
            "hidden_layers": 2,
            "activation": "relu",
            "loss": loss,
            "huber_delta": 0.2,
            "optimizer": "Adam",
            "learning_rate": 0.001,
            "weight_decay": 0.0001,
            "batch_size": 256,
            "epochs": epochs,
            "score_epochs": score_epochs,
            "offsets": list(OFFSETS),
            "feature_order": "six_neighbor_values_then_six_availability_indicators",
            "history_length": 32,
            "init_seed": int(initialization.generate_state(1)[0]),
            "shuffle_seed": int(shuffle.generate_state(1)[0]),
            "device": device,
            "smoke": smoke,
        }
        require(
            read(folder / "config.json") == candidate["config"] == expected_config,
            f"{name}: mediator recipe or private RNG streams differ",
        )
        with torch.random.fork_rng(devices=[]):
            torch.random.default_generator.manual_seed(expected_config["init_seed"])
            initial = BlindSpotMediator(width)
        initial_hash = mediator_state_hash(initial.state_dict())
        logs = [
            json.loads(line)
            for line in (folder / "training.jsonl").read_text().splitlines()
        ]
        updates_per_epoch = math.ceil(train.size / 256)
        require(
            [row["epoch"] for row in logs] == list(range(1, epochs + 1)),
            f"{name}: mediator epoch inventory differs",
        )
        require(
            all(
                row["optimizer_updates"] == row["epoch"] * updates_per_epoch
                for row in logs
            ),
            f"{name}: mediator optimizer budget differs",
        )
        selection = read(folder / "validation.json")
        require(
            selection
            == [
                {"epoch": row["epoch"], "validation_mse": row["validation_mse"]}
                for row in logs
                if "validation_mse" in row
            ],
            f"{name}: mediator selection logs differ",
        )
        require(
            [row["epoch"] for row in selection] == score_epochs,
            f"{name}: mediator validation cadence differs",
        )
        best = min(selection, key=lambda row: row["validation_mse"])
        checkpoint = torch.load(
            folder / "best.pt", map_location="cpu", weights_only=True
        )
        model = load_mediator(folder / "best.pt", device=device)
        predictions = np.load(
            folder / "best_validation_predictions.npy", allow_pickle=False
        )
        equal(
            predictions,
            learned_history(model, validation),
            f"{name}: selected predictions",
        )
        score = float(np.mean((predictions - validation) ** 2))
        require(
            score
            == best["validation_mse"]
            == candidate["validation_mse"]
            == checkpoint["validation_mse"],
            f"{name}: noisy-center score does not reproduce",
        )
        require(
            best["epoch"] == candidate["selected_epoch"] == checkpoint["epoch"]
            and checkpoint["optimizer_updates"] == best["epoch"] * updates_per_epoch
            and candidate["optimizer_updates"] == epochs * updates_per_epoch,
            f"{name}: mediator checkpoint is not the first validation argmin",
        )
        require(
            checkpoint["config"] == expected_config
            and checkpoint["initial_sha256"]
            == candidate["initial_sha256"]
            == initial_hash
            and candidate["selected_sha256"] == mediator_state_hash(checkpoint["model"])
            and candidate["checkpoint_sha256"] == sha256(folder / "best.pt"),
            f"{name}: mediator checkpoint provenance differs",
        )
    best = min(candidates, key=lambda row: row["validation_mse"])
    require(
        summary["selected"] == best["name"]
        and summary["selected_epoch"] == best["selected_epoch"]
        and summary["validation_mse"] == best["validation_mse"]
        and sha256(directory / "selected.pt")
        == best["checkpoint_sha256"]
        == summary["selected_checkpoint_sha256"],
        "Mediator candidate selection or byte-identical selected checkpoint differs",
    )
    model = load_mediator(directory / "selected.pt", device=device)
    with np.load(directory / "selected_predictions.npz", allow_pickle=False) as saved:
        for split, history in (("train", train), ("validation", validation)):
            expected = learned_history(model, history)
            equal(
                saved[f"{split}_predictions"],
                expected,
                f"Mediator selected {split} history",
            )
            require(
                array_hash(expected) == summary[f"{split}_predictions_sha256"],
                f"Mediator selected {split} hash differs",
            )
    return model, summary
